# Telegram AI Bot

## Overview
A Telegram bot powered by OpenAI's GPT-5 that provides intelligent conversational responses. The bot maintains conversation history for each user and responds naturally to messages.

## Features
- AI-powered responses using GPT-5 (latest OpenAI model)
- Conversation history tracking (last 10 messages per user)
- Simple commands: /start, /clear, /help
- Error handling and typing indicators

## Project Architecture
- **index.js**: Main bot application
- **Dependencies**: 
  - node-telegram-bot-api: Telegram Bot API wrapper
  - openai: OpenAI API client

## Environment Variables
- `TELEGRAM_BOT_TOKEN`: Bot token from @BotFather
- `OPENAI_API_KEY`: OpenAI API key

## Recent Changes
- 2025-10-28: Initial project creation with GPT-5 integration and conversation history

## How to Use
1. Start a chat with your bot on Telegram
2. Send /start to begin
3. Send any message to get an AI response
4. Use /clear to reset conversation history
5. Use /help to see available commands
