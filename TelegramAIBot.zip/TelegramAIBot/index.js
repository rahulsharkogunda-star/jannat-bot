import express from "express";
import fetch from "node-fetch";
import bodyParser from "body-parser";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(bodyParser.json());

const TELEGRAM_TOKEN = process.env.TELEGRAM_TOKEN;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const HUGGINGFACE_TOKEN = process.env.HUGGINGFACE_TOKEN;
const HUGGINGFACE_MODEL_URL = process.env.HUGGINGFACE_MODEL_URL;

// 💫 Core AI handler — auto switch + retry logic
async function getAIReply(userMsg) {
  let replyText = "";

  // 🧠 Try Gemini first
  try {
    console.log("🌟 Trying Gemini...");
    const geminiRes = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: userMsg }] }],
        }),
      }
    );

    const geminiData = await geminiRes.json();
    replyText = geminiData?.candidates?.[0]?.content?.parts?.[0]?.text;

    if (replyText) {
      console.log("✅ Gemini Success");
      return replyText;
    }
    throw new Error("Gemini gave no valid response");

  } catch (err) {
    console.log("⚠️ Gemini failed, switching to HuggingFace...", err.message);

    // 💬 Try HuggingFace next
    try {
      const hfRes = await fetch(HUGGINGFACE_MODEL_URL, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${HUGGINGFACE_TOKEN}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ inputs: userMsg }),
      });

      const hfData = await hfRes.json();
      if (Array.isArray(hfData) && hfData[0]?.generated_text) {
        replyText = hfData[0].generated_text;
      } else if (hfData?.generated_text) {
        replyText = hfData.generated_text;
      }

      if (replyText) {
        console.log("✅ HuggingFace Success");
        return replyText;
      }
      throw new Error("HF gave no valid response");

    } catch (hfErr) {
      console.log("⚠️ HuggingFace also failed, retrying Gemini once more...");

      // ♻️ Final Retry — Back to Gemini
      try {
        const geminiRetry = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${GEMINI_API_KEY}`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              contents: [{ parts: [{ text: userMsg }] }],
            }),
          }
        );

        const retryData = await geminiRetry.json();
        replyText = retryData?.candidates?.[0]?.content?.parts?.[0]?.text;

        if (replyText) {
          console.log("♻️ Gemini retry success!");
          return replyText;
        }
      } catch (finalErr) {
        console.log("❌ Both APIs down. Sending fallback message...");
      }

      // 😴 Final fallback if both failed
      replyText = "😴 Jannat thoda rest le rahi hai... thodi der baad try karo 💖";
      return replyText;
    }
  }
}

// 💌 Telegram webhook handler
app.post("/webhook", async (req, res) => {
  try {
    const message = req.body.message;
    if (!message || !message.text) return res.sendStatus(200);

    const userMsg = message.text;
    console.log(`💬 User: ${userMsg}`);

    const aiReply = await getAIReply(userMsg);

    // ✨ Send back reply to Telegram
    await fetch(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: message.chat.id,
        text: aiReply,
      }),
    });

    res.sendStatus(200);
  } catch (error) {
    console.error("❌ Webhook Error:", error);
    res.sendStatus(500);
  }
});

// 🚀 Start Server
app.listen(5000, () => {
  console.log("💖 Jannat Immortal Hybrid Bot is live on port 5000 💫");
});
